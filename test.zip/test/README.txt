Steps:
1.Run hello.htm file

Create customer
2.Click on 'customer' tab
3.Add details.
4.Click on create button

Search customer:
1.Click on Search button
2.enter the customer name in the prompt box
3.add  new values and edit customer
